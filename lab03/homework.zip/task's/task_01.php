<?php
/*
$a = 0;
$b = 0;
for ($i = 0; $i <= 5; $i++) {
    $a += 10;
    $b += 5;
}
echo "<br />Sfarsit ciclu, si valoarea lui a = " . $a . ", iar a
lui b = " . $b;
*/


$a = 0;
$b = 0;
for ($i = 0; $i <= 5; $i++) {
    $a += 10;
    $b += 5;
    echo "Iterația $i: a = $a, b = $b <br />";
}
echo "<br />Sfarsit ciclu, si valoarea lui a = " . $a . ", iar a lui b = " . $b;

?>